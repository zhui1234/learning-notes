// path_optimizer.h
#ifndef PATH_OPTIMIZER_H
#define PATH_OPTIMIZER_H

#include <stdbool.h>

#define MAX_SENSORS 100
#define MAX_POINTS 100
#define MAX_PATH_LEN 100
#define MAX_SCORE 300.0
#define SCORE_OF_BASELINE 300*0.7

typedef struct {
    double x;
    double y;
} Point;

typedef struct  {
    double arrive;
    double depart;
}Times ;

typedef struct {
    int count;
    int* snindex;
} SNarray;

typedef struct {
    int is_success;
    double profits;
} Result;

typedef struct {
    int width;
    int length;
    int M;
    int N;
    double E_max;
    Point init_location;
    double D_max;
    double V_max;
    double T_com;
    double T_charge;
    double alpha;

    Point sensor_pos[MAX_SENSORS];
    int Ri[MAX_SENSORS];
    int visited[MAX_SENSORS];
    double sampletime[MAX_SENSORS];
    double offloadtime[MAX_SENSORS]; 
    
    int num_pos;
    Point path[MAX_SENSORS];
	Times timelabel[MAX_SENSORS];
	SNarray visit_sn[MAX_SENSORS];    
} PathOptimizer;

typedef struct InteractiveSystem{
    double width;
    double length;
    int M;
    int N;
    double E_max;
    double V_max;
    double D_max;
    double alpha; 
    double T_com;
    double T_charge;
    Point init_location;
 
    Point* sensor_pos;
    int* Ri;
    
    PathOptimizer path_optimizer;
} InteractiveSystem;


void path_optimizer_init(PathOptimizer* optimizer, struct InteractiveSystem* system);
double path_optimizer_run(PathOptimizer* optimizer);
double cal_distance(Point p1, Point p2);
double cal_uav_power(double velocity);

#endif

