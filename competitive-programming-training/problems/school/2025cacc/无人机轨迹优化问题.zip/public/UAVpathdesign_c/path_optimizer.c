#include <stdio.h>
#include <stdlib.h>
#include <string.h> 
#include <math.h>
#include <stdbool.h>
#include "path_optimizer.h"


void path_optimizer_init(PathOptimizer* po, struct InteractiveSystem* system) {    
    int i;
    po->length = system->length;
    po->width = system->width;
    po->E_max = system->E_max;
    //po->M = 10;
    //po->N = system->N+1;
    po->M = system->M;
    po->N = system->N;
    po->init_location.x = 0.0;
    po->init_location.y = 0.0;
    po->D_max = 300.0;
    po->V_max = 30.0;
    po->T_com = 1.0;
    po->T_charge = 120.0;
    po->alpha = 0.1;
    
    for (i = 0; i < po->M; i++) {
        po->sensor_pos[i] = system->sensor_pos[i];
        po->Ri[i] = system->Ri[i];
        po->visited[i] = 0;
        po->sampletime[i] = 0.0;
        po->offloadtime[i] = 0.0;
    }
    
    // po->visit_sn根据数据收集点数分配内存，暂时不初始化
    // for (i = 0; i < MAX_SENSORS; i++) {
    //     po->visit_sn[i].snindex = NULL;
    // }    
}

// TODO: 在这个函数中完成路径规划功能，注意返回数据结构格式
// 返回profits, 其他数据收集点信息（路径长度，飞行路径，时间标签，所收集的节点序号）和 节点信息（采样时间，卸载时间）放在PathOptimizer类成员中
double path_optimizer_run(PathOptimizer* po) {
     
    double profits = -1.0;   
  
   
    return profits;
}


double cal_distance(Point a, Point b) {
    return sqrt(pow(a.x - b.x, 2) + pow(a.y - b.y, 2));
}

double cal_uav_power(double v) {
    const double P0 = 79.8563;
    const double P1 = 88.6279;
    const double a = 0.00021;
    const double b = 0.00924;
    const double c = 0.00073;
    const double d = 0.02704;

    return P0 * (1 + a * v*v) + b * v*v*v + 
           P1 * sqrt(sqrt(1 + c * pow(v,4)) - d * v*v);
}
