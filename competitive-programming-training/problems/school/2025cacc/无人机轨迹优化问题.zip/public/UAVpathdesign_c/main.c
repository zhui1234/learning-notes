#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdbool.h>
#include <string.h>
#include "path_optimizer.h"


double* split_and_convert(const char *line, int *size) {
    char *str = strdup(line);
    char *token = strtok(str, " ");
    int count = 0;
    double *result = malloc(sizeof(double) * 100); 
 
    while (token != NULL) {
        result[count++] = atof(token);
        token = strtok(NULL, " ");
    }
 
    *size = count;
    free(str);
    
    return result;
}

void read_from_file(struct InteractiveSystem* system, const char* file_name){	
	FILE *file = fopen(file_name, "r");   
    char line[1024];
    int params_size, prof;    
    char *token;
    double x, y;
    int count = 0;
    double *params;
    
    if (file == NULL) {
        perror("Failed to open file");
        exit(EXIT_FAILURE);
    }
    if (fgets(line, sizeof(line), file) == NULL) {
        perror("Failed to read first line");
        fclose(file);
        exit(EXIT_FAILURE);
    }
 
    params= split_and_convert(line, &params_size);
    if (params_size != 5) {
        fprintf(stderr, "Invalid number of parameters in the first line\n");
        fclose(file);
        free(params);
        exit(EXIT_FAILURE);
    }
 
    system->width = params[0];
    system->length = params[1];
    system->E_max = params[2];
    system->M = (int)params[3];
    system->N = (int)params[4];
    free(params);
    
//    fprintf(stderr, " %f %f %f %d %d \n", system->width, system->length, system->E_max, system->M, system->N );
   
    system->sensor_pos = malloc(sizeof(Point)*system->M);
    system->Ri = malloc(sizeof(int)*system->M);
 
    while (fgets(line, sizeof(line), file)) {
        token = strtok(line, " ");
        x = atof(token);
        token = strtok(NULL, " ");
        y = atof(token);
        token = strtok(NULL, " ");
        prof = atoi(token);
        
        system->sensor_pos[count].x = x;
        system->sensor_pos[count].y = y;
 
        system->Ri[count] = prof;
        count += 1;
    }
 	
// 	for (count=0; count < system->M; count++){	  		
// 		 fprintf(stderr, " %f %f %d \n", system->sensor_pos[count].x, system->sensor_pos[count].y, system->Ri[count]);   
//	 }
 	
    fclose(file);
    return;
}

void InteractiveSystem_init(struct InteractiveSystem* system, const char* file_name) {	
    system->V_max=30.0;
    system->D_max = 300.0;
    system->alpha = 0.1; 
    system->T_com = 1.0;
    system->T_charge = 120.0;
    system->init_location.x = 0.0;
    system->init_location.y = 0.0;
    system->sensor_pos = NULL;
    system->Ri = NULL;
 
    read_from_file(system, file_name);       
    path_optimizer_init(&system->path_optimizer, system);    
    
	return;     
}
 
Result InteractiveSystem_runOnce(struct InteractiveSystem* system) {
	Result ouT_come;
	ouT_come.is_success = 1;
	ouT_come.profits = -1.0;
    double reward = 0.0;
    double worktime = 0.0;
    double remaining_e_uav = system->E_max;
    Point pos, p1, p2;
    double distance, flytime, velocity;
    Times previous, current;
    int i, nn, visitnum, numpos;
    double profits;
    
    profits = path_optimizer_run(&system->path_optimizer);
      
    if ((profits < 0.0) || (system->path_optimizer.num_pos <= 0) ){
    	ouT_come.is_success = 0;
	}
    else{
    	visitnum = 0;
    	numpos = system->path_optimizer.num_pos;
    	for (i = 1; i < numpos-1; i++){
    		pos.x = system->path_optimizer.path[i].x;
    		pos.y = system->path_optimizer.path[i].y;
    		 
    		if ((pos.x < 0.0) || (pos.x>system->length)){
    		 	ouT_come.is_success = 0;
    		 	break;
			}else if ((pos.y < 0.0) && (pos.y>system->width)){
			 	ouT_come.is_success = 0;
			 	break;
			}else{
			 	previous = system->path_optimizer.timelabel[i-1];
			 	current = system->path_optimizer.timelabel[i];
			 	
			 	if ((current.depart < current.arrive) || (previous.depart >= current.arrive)) {
			 		ouT_come.is_success = 0;
			 		break;
				 }				
			}
			 
			visitnum += system->path_optimizer.visit_sn[i].count;			 
		}
		
		if (visitnum != system->M){
			ouT_come.is_success = 0;
		}
		else{
			for (i = 1; i < numpos; i++){
				p1 = system->path_optimizer.path[i-1];
				p2 = system->path_optimizer.path[i];
				distance = cal_distance(p1, p2);
				previous = system->path_optimizer.timelabel[i-1];
			 	current = system->path_optimizer.timelabel[i];
				flytime = current.arrive-previous.depart;
				 if (flytime > 0) {
                    velocity = distance / flytime;
                    if (velocity > system->V_max && fabs(velocity - system->V_max) > 0.01) {
                        ouT_come.is_success = 0;
                        break;
                    } else {
                        remaining_e_uav -= cal_uav_power(velocity) * flytime;
                    }
                } else {
                    ouT_come.is_success = 0;
                    break;
                }
                
				distance=cal_distance(p2, system->init_location);
                if (distance > 0.1 && system->path_optimizer.visit_sn[i].count > 0) {
                    nn = (int)ceil(system->path_optimizer.visit_sn[i].count / system->N);
                    remaining_e_uav -= cal_uav_power(0) * (nn * system->T_com);
                }
             
	            if ( i < numpos - 1 && distance <= 0.1) {
	                    remaining_e_uav = system->E_max;
	            }
	          
	            if (remaining_e_uav < 0) {
	                ouT_come.is_success = 0;
	                break;
	            }	    
			}
	    }
		
		if (ouT_come.is_success > 0) {
	        for (i = 0; i < system->M; i++) {
	    		reward += system->Ri[i] / (system->path_optimizer.offloadtime[i] - system->path_optimizer.sampletime[i]);
	        }
	  		
			for (i = 1; i < numpos; i++) {
				previous = system->path_optimizer.timelabel[i-1];
			 	current = system->path_optimizer.timelabel[i];
				flytime = current.arrive-previous.depart;
				
	            worktime += flytime;
	            p1 = system->path_optimizer.path[i]; 
	            distance=cal_distance(p1, system->init_location);
				if (current.arrive < current.depart) {
	            	if (distance >0.01) {
	                    worktime += current.depart - current.arrive;
	                } else {
	                    worktime += system->T_charge;
	                }
	                   
	            }	              			
			}
            
			reward -= worktime * system->alpha;	
			ouT_come.profits = reward;
	    }         
	}
	
	for (i = 0; i < numpos; i++) {
		if (system->path_optimizer.visit_sn[i].count > 0){
			free(system->path_optimizer.visit_sn[i].snindex);
		}
	}
	
	if (system->sensor_pos != NULL){
		free(system->sensor_pos);
	}	
	if (system->Ri != NULL){
		free(system->Ri);
	}		
    return ouT_come; 
}

int main() {
   
    const char *mode = "GEN_SCH_SCORE";
    int i, n_tests = 5;
    double total_score = 0;
    double *score_list = (double *) malloc(n_tests * sizeof(double));
    Result ouT_come;
    double baseline;
    double score;
    char file_name[256];
    InteractiveSystem inter_sys;
	        
    if (strstr(mode, "GEN_SCH_SCORE") != NULL) {
        const char *score_path = "./final_score.txt";
        FILE *score_file = fopen(score_path, "w");
        if (score_file == NULL) {
            perror("Failed to open score file");
            exit(EXIT_FAILURE);
        }
   
        for (i = 1; i <= n_tests; i++) {
            fprintf(stderr, "test case #%d: ", i);
                        
            snprintf(file_name, sizeof(file_name), "./data/%d.in", i);
            InteractiveSystem_init(&inter_sys, file_name);
            ouT_come = InteractiveSystem_runOnce(&inter_sys);
            
            snprintf(file_name, sizeof(file_name), "./data/baseline_%d.out", i);
            FILE *baseline_file = fopen(file_name, "r");
            if (baseline_file == NULL) {
                perror("Failed to open baseline file");
                exit(EXIT_FAILURE);
            }
            
			if(fscanf(baseline_file, "%lf", &baseline) != 1){
				fprintf(stderr, "Failed to read a float from the file.\n");
		        fclose(baseline_file);
		        exit(EXIT_FAILURE);
			}
			
            //fprintf(stderr, "Baseline: %f\n", baseline);
            
			score = 0.0;
            if (ouT_come.is_success > 0) {
                score = 1.0 * ouT_come.profits  / baseline  * SCORE_OF_BASELINE;
                if (score > MAX_SCORE) score = MAX_SCORE;
            }
            score_list[i - 1] = score;
            total_score += score;
            fprintf(stderr, "%.2f\n", score);
            fclose(baseline_file);
        }
        fprintf(stderr, "Final Score: %.2f\n", total_score / n_tests);
        fprintf(score_file, "Final Score: %.2f\n", total_score / n_tests);
        for (i = 0; i < n_tests; i++) {
            fprintf(score_file, "Score of Test Case #%d: %.2f\n", i + 1, score_list[i]);
        }
        free(score_list);
        fclose(score_file);
    }
    
    return 0;

}
