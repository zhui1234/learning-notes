
from typing import Tuple, List
import math
import itertools
import sys

class Path_optimizer:
    def __init__(self):
        self.width = 0  # 环境宽度 单位m
        self.length = 0  # 环境长度
        self.M = 0  # 节点数量 M
        self.N = 0  # UAV一次访问节点数 N
        self.init_location = (0.0, 0.0)
        self.E_max = 0.0
        self.V_max = 30  # 最大飞行速度
        self.D_max = 300  # 无人机覆盖半径/m
        self.alpha = 0.1  # 折扣系数discount
        self.T_com = 1  # 一次数据传输时间
        self.T_charge = 120  # 一次充电时间

        self.sensor_pos: List[Tuple[float, float]] = []
        self.Ri: List[int] = []  # profits of sensor nodes
        self.visited: List[int] = []  # visiting state
        self.remaining_e_uav: List[float] = []  # UAV的剩余电量
        self.path: List[Tuple[float, float]] = []
        self.timelabel: List[Tuple[float, float]] = []
        self.sampletime: List[float] = []
        self.offloadtime: List[float] = []
        self.sensor_visited = []

    def init(self, length: float, width: float, E_max: float, M: int, N: int,
             sensor_pos: List[Tuple[float, float]], Ri: List[int]):
        self.length = length  # 环境长度
        self.width = width  # 环境宽度 单位m
        self.E_max = E_max
        self.M = M  # 节点数量 M
        self.N = N  # UAV一次访问节点数 N
        self.sensor_pos = sensor_pos
        self.Ri = Ri

        self.visited = [0] * self.M
        self.sampletime = [0.0] * self.M
        self.offloadtime = [0.0] * self.M

    # TODO: 在这个函数中完成路径规划功能，注意返回数据结构格式
    # 返回profits, 数据收集点信息（路径长度，飞行路径，时间标签，所收集的节点序号）， 节点信息（采样时间，卸载时间）对
    def run(self):
        profits = -1

        return profits, (len(self.path), self.path, self.timelabel, self.sensor_visited), (self.sampletime, self.offloadtime)



    def cal_distance(self, point1, point2):
        """计算两个点之间的欧几里得距离"""
        return math.sqrt((point1[0] - point2[0]) ** 2 + (point1[1] - point2[1]) ** 2)

    def cal_uav_power(self, v):
        P0 = 79.8563
        P1 = 88.6279
        a = 0.00021
        b = 0.00924
        c = 0.00073
        d = 0.02704

        power = P0 * (1 + a * v ** 2) + b * v ** 3 + P1 * math.sqrt(math.sqrt(1 + c * v ** 4) - d * v ** 2)

        return power