import sys
import os
from typing import List, Tuple
from path_optimizer import Path_optimizer
import random
import math

MAX_SCORE = 300.0
SCORE_OF_BASLINE = 300.0 * 0.7

class InteractiveSystem:
    def __init__(self):
        self.width = 0       # 环境宽度 单位m
        self.length = 0      # 环境长度
        self.M = 0      # 节点数量 M
        self.N = 0   # UAV一次访问节点数 N
        self.E_max = 0.0
        self.V_max = 30  # 最大飞行速度
        self.D_max = 300  # 无人机覆盖半径/m
        self.alpha = 0.1  # 折扣系数
        self.T_com = 1 # 一次数据传输时间
        self.T_charge = 120 # 一次充电时间
        self.init_location = [0.0, 0.0]

        self.sensor_pos:List[float] = []
        self.Ri: List [int] = []  # profits of sensor nodes
        self.profits = - 1.0
        self.path = []
        self.sensor = []
        self.path_optimizer = Path_optimizer()

    def init(self, file_name: str):
        self.alpha = 0.1
        self.V_max = 30  # 最大飞行速度
        self.D_max = 300  # 无人机覆盖半径/m
        self.T_com = 1  # 一次数据传输时间
        self.T_charge = 120  # 一次充电时间
        self.init_location = [0.0, 0.0]
        self.length, self.width,  self.E_max,  self.M, self.N, self.sensor_pos, self.Ri  = read_from_file(file_name)
        self.path_optimizer.init(self.width, self.length, self.E_max,  self.M, self.N, self.sensor_pos, self.Ri)

    def runOnce(self):

        self.profits, self.path, self.sensor = self.path_optimizer.run()

        is_success = True
        visited = [1 for i in range(1, self.M + 1)]

        num_pos = self.path[0]      # 数据收集点数（不包括驻点）
        uav_path = self.path[1]     # 无人机轨迹（包括离开和回到驻点）
        time_seq = self.path[2]     # 到达和离开数据收集点时间, 首次从驻点离开时间为（0，0）
        visit_sn = self.path[3]     # 在每个数据收集点访问的节点序号
        # 检查是否满足能量要求
        remaining_e_uav = self.E_max
        reward = 0.0
        worktime = 0.0

        # 检查结果
        if self.profits < 0.0 or len(uav_path) != num_pos or len(time_seq) != num_pos or len(visit_sn) != num_pos:
            is_success = False
        else:
            for i in range(1, num_pos-1):
                pos_x, pos_y = uav_path[i]
                if pos_x > self.length or pos_x < 0:
                    is_success = False
                if pos_y > self.width or pos_y < 0:
                    is_success = False
                time_arrive, time_depart = time_seq[i]
                if time_depart < time_arrive:
                    is_success = False
                else:
                    time_arrive2, time_depart2 = time_seq[i-1]
                    if time_depart2 >= time_arrive:
                        is_success = False
                sn_ind = visit_sn[i]
                for j in range(len(sn_ind)):
                    visited[sn_ind[j]-1] = 1

            if sum(visited) != self.M:
                is_success = False
            else:
                for i in range(1, num_pos):  # 循环所有点
                    distance = self.path_optimizer.cal_distance(uav_path[i-1], uav_path[i])
                    flytime = time_seq[i][0] - time_seq[i-1][1]
                    if flytime>0:
                        velocity = distance / flytime
                        if velocity > self.V_max and abs(velocity - self.V_max) > 0.01:
                            is_success = False
                        else:
                            remaining_e_uav -= self.path_optimizer.cal_uav_power(velocity) * flytime
                    else:
                        is_success = False

                    dist_intial = self.path_optimizer.cal_distance(uav_path[i], self.init_location)
                    if dist_intial > 0.1 and len(visit_sn[i]) > 0:
                        nn = math.ceil(len(visit_sn[i]) / self.N)  # nn次传输
                        remaining_e_uav -= self.path_optimizer.cal_uav_power(0) * (nn * self.T_com)

                    if i < num_pos-1 and dist_intial <= 0.1:
                        remaining_e_uav = self.E_max

                    if remaining_e_uav < 0:
                        is_success = False
                        break

            if is_success:  # check profits
                for i in range(self.M):
                    reward += self.Ri[i]/(self.sensor[1][i]-self.sensor[0][i])

                for i in range(1, num_pos):
                    worktime += time_seq[i][0] - time_seq[i - 1][1]
                    if time_seq[i][0] < time_seq[i][1]:
                        if uav_path[i] != self.init_location:
                            worktime += time_seq[i][1]- time_seq[i][0]
                        else:
                            worktime += self.T_charge

                reward -= worktime * self.alpha

        return is_success, reward


def read_from_file(filename):
    with open(filename, 'r') as file:
        line = file.readline()
        width, length, energy_max, M, N = map(int, line.split())
    sensor_data = []
    for line in open(filename).readlines()[1:]:
        x, y, prof = map(int, line.split())
        sensor_data.append(((x, y), prof))

    sensor_pos = [pos for pos, prof in sensor_data]
    Ri = [prof for pos, prof in sensor_data]

    return width, length, energy_max, M, N, sensor_pos, Ri

def main():
    mode = "GEN_SCH_SCORE"
    if "GEN_SCH_SCORE" in mode:
        score_path = "./final_score.txt"
        with open(score_path, 'w') as f:
            sys.stdout = f
            n_tests = 5
            total_score = 0
            score_list = [0] * n_tests
            for i in range(1, n_tests + 1):
                print(f"\ntest case #{i}: ", file=sys.stderr, end='')
                inter_sys = InteractiveSystem()
                file_name = f"./data/{i}.in"
                inter_sys.init(file_name)
                is_success, profits = inter_sys.runOnce()
                print("%d %.2f \n" % (is_success, profits), file=sys.stderr)
                if is_success:
                    file_name = f"./data/baseline_{i}.out"
                    with open(file_name, 'r') as baseline_file:
                        line = baseline_file.readline().strip()
                        baseline = float(line)
                        score = min(MAX_SCORE, 1.0 * profits/ baseline * SCORE_OF_BASLINE)
                        total_score += score
                        print("%.2f" % score, file=sys.stderr)
                else:
                    score = 0.0
                score_list[i-1] = score #修改score_list
            print("\nFinal Score: %.2f" % (total_score / n_tests), file=sys.stderr)
            print("\nFinal Score: %.2f" % (total_score / n_tests))
            for i in range(n_tests):
                print("Score of Test Case #%d: %.2f" % (i + 1, score_list[i]))
            # Additional processing can be added here if needed

if __name__ == "__main__":
    main()


