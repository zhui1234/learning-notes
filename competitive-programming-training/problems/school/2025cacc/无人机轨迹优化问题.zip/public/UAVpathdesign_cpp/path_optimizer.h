#ifndef PATH_OPTIMIZER_H
#define PATH_OPTIMIZER_H

#include <vector>
#include <tuple>
#include <cmath>
#include <algorithm>
#include <limits>
#include <set>
#include <iostream>

// 位置坐标的类型别名
struct Point {
    double x;
    double y;

     // 添加比较运算符以便使用next_permutation
    bool operator<(const Point& other) const {
        return x < other.x || (x == other.x && y < other.y);
    }
};

struct Times {
    double arrive;
    double depart;
};

struct SNarray {
	int count = 0;
    std::vector<int> snindex;
};

struct Result {
    int is_success;
    double profits;
};
 

class PathOptimizer {
private:
    double width;             // 环境宽度 单位m
    double length;            // 环境长度
    int M;                    // 节点数量 M
    int N;                    // UAV一次访问节点数 N
    Point init_location;      // 初始位置
    double E_max;             // 最大能量
    double V_max;             // 最大飞行速度
    double D_max;             // 无人机覆盖半径/m
    double alpha;             // 折扣系数discount
    double T_com;             // 一次数据传输时间
    double T_charge;          // 一次充电时间

    std::vector<Point> sensor_pos;               // 传感器位置
    std::vector<int> Ri;                         // 传感器节点收益
    std::vector<int> visited;                    // 访问状态
    std::vector<double> remaining_e_uav;         // UAV的剩余电量   
   
    // 私有方法
    std::tuple<std::vector<Point>, std::vector<std::vector<int>>, double> find_collect_points();
    std::tuple<double, std::vector<Point>, std::vector<int>> find_layer1_collect_points(const std::vector<Point>& col_pos);
    std::vector<Point> schedule_uav_path(const Point& start, const std::vector<Point>& points, double unit, 
                                       const std::vector<Point>& col_pos, const std::vector<int>& connect);
    double cal_profits_times(const std::vector<Point>& fly_path, double velocity, 
                           const std::vector<std::vector<int>>& sensor_visited);
    std::tuple<double, std::vector<std::vector<int>>, std::vector<int>> cal_hover_energy(
        const std::vector<Point>& uav_path, const std::vector<Point>& col_pos, 
        const std::vector<std::vector<int>>& sn_associate);
    std::tuple<bool, double, double> cal_fly_energy(
        const std::vector<Point>& update_path, double res_energy);
    std::tuple<bool, double> schedule_uav_charge_path(
        const std::vector<Point>& fly_path, 
        const std::vector<std::vector<int>>& sensor_visited,
        double res_energy);
    
public:
    std::vector<Point> path;                     // 路径
    std::vector<Times> timelabel;  // 时间标签
    std::vector<double> sampletime;              // 采样时间
    std::vector<double> offloadtime;             // 卸载时间
    std::vector<std::vector<int>> sensor_visited;// 访问的传感器
    
    // 构造函数
    PathOptimizer();

    // 初始化函数
    void init(double length, double width, double E_max, int M, int N,
              const std::vector<Point>& sensor_pos, const std::vector<int>& Ri);

    // 运行优化算法
    double run();

    // 计算两点之间的距离
    double cal_distance(const Point& point1, const Point& point2);

    // 计算UAV功率
    double cal_uav_power(double v);
};


class InteractiveSystem {
    private:
        double width;            // 环境宽度 单位m
        double length;           // 环境长度
        int M;                   // 节点数量 M
        int N;                   // UAV一次访问节点数 N
        double E_max;
        double V_max;            // 最大飞行速度
        double D_max;            // 无人机覆盖半径/m
        double alpha;            // 折扣系数
        double T_com;            // 一次数据传输时间
        double T_charge;         // 一次充电时间
        Point init_location;     // 初始位置
        
        std::vector<Point> sensor_pos;           // 传感器位置
        std::vector<int> Ri;                     // 传感器节点收益
        double profits;                          // 收益
        std::vector<Point> path;                 // 路径
        std::vector<int> sensor;                 // 传感器
        PathOptimizer path_optimizer;            // 路径优化器
    
    public:
        // 构造函数
        InteractiveSystem();
        
        // 初始化函数
        void init(const std::string& file_name);
        
        // 运行一次
        Result runOnce();
    };
    
    // 从文件读取数据
    std::tuple<double, double, double, int, int, std::vector<Point>, std::vector<int>> 
    read_from_file(const std::string& filename);

    #endif // PATH_OPTIMIZER_H 