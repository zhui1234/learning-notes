#include "path_optimizer.h"
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>
#include <sstream>
#include <cmath>
#include <algorithm>
#include <numeric>

const double MAX_SCORE = 300.0;
const double SCORE_OF_BASLINE = 300.0 * 0.7;

// 构造函数
InteractiveSystem::InteractiveSystem() {
    width = 0;            // 环境宽度 单位m
    length = 0;           // 环境长度
    M = 0;                // 节点数量 M
    N = 0;                // UAV一次访问节点数 N
    E_max = 0.0;
    V_max = 30;           // 最大飞行速度
    D_max = 300;          // 无人机覆盖半径/m
    alpha = 0.1;          // 折扣系数
    T_com = 1;            // 一次数据传输时间
    T_charge = 120;       // 一次充电时间
    init_location = {0.0, 0.0};
    
    profits = -1.0;
}

// 初始化函数
void InteractiveSystem::init(const std::string& file_name) {
    alpha = 0.1;
    V_max = 30;           // 最大飞行速度
    D_max = 300;          // 无人机覆盖半径/m
    T_com = 1;            // 一次数据传输时间
    T_charge = 120;       // 一次充电时间
    init_location = {0.0, 0.0};
    
    // 从文件读取数据
    std::tie(length, width, E_max, M, N, sensor_pos, Ri) = read_from_file(file_name);
    
    // 初始化路径优化器
    path_optimizer.init(length, width, E_max, M, N, sensor_pos, Ri);
}

// 运行一次
Result InteractiveSystem::runOnce() {
    Result ouT_come;
    ouT_come.is_success = 1;
    ouT_come.profits = -1.0;
    
    double reward = 0.0;
    double worktime = 0.0;
    double remaining_e_uav = E_max;
    Point pos, p1, p2;
    double distance, flytime, velocity;
    Times previous, current;
    int visitnum = 0;
    int numpos = 0;
    
    profits = path_optimizer.run();      
    numpos = path_optimizer.path.size();
    
    if (profits < 0.0 || numpos <= 0) {
        ouT_come.is_success = 0;
    }else {
        for (int i = 1; i < numpos - 1; i++) {
            pos = path_optimizer.path[i];            
            if (pos.x < 0.0 || pos.x > length || pos.y < 0.0 || pos.y > width) {
                ouT_come.is_success = 0;
                break;
            }

            previous = path_optimizer.timelabel[i - 1];
            current = path_optimizer.timelabel[i];
            
            if (current.depart < current.arrive || previous.depart >= current.arrive) {
                ouT_come.is_success = 0;
                break;
            }

            visitnum += path_optimizer.sensor_visited[i].size();
        }
        
        if (visitnum != M) {
            ouT_come.is_success = 0;
        } else {
            for (int i = 1; i < numpos; i++) {
                p1 = path_optimizer.path[i - 1];
                p2 = path_optimizer.path[i];
                distance = path_optimizer.cal_distance(p1, p2);

                previous = path_optimizer.timelabel[i - 1];
                current = path_optimizer.timelabel[i];
                flytime = current.arrive - previous.depart;
                
                if (flytime > 0) {
                    velocity = distance / flytime;
                    if (velocity > V_max && std::fabs(velocity - V_max) > 0.01) {
                        ouT_come.is_success = 0;
                        break;
                    } else {
                        remaining_e_uav -= path_optimizer.cal_uav_power(velocity) * flytime;
                    }
                } else {
                    ouT_come.is_success = 0;
                    break;
                }

                distance = path_optimizer.cal_distance(p2, init_location);
                if (distance > 0.1 && path_optimizer.sensor_visited[i].size() > 0) {
                    int nn = static_cast<int>(std::ceil(path_optimizer.sensor_visited[i].size() / N));
                    remaining_e_uav -= path_optimizer.cal_uav_power(0) * (nn * T_com);
                }

                if (i < numpos - 1 && distance <= 0.1) {
                    remaining_e_uav = E_max;
                }

                if (remaining_e_uav < 0) {
                    ouT_come.is_success = 0;
                    break;
                }
            }
        }

        if (ouT_come.is_success > 0) {
            for (int i = 0; i < M; i++) {
                reward += Ri[i] / (path_optimizer.offloadtime[i] - path_optimizer.sampletime[i]);
            }

            for (int i = 1; i < numpos; i++) {
                previous = path_optimizer.timelabel[i - 1];
                current = path_optimizer.timelabel[i];
                flytime = current.arrive - previous.depart;

                worktime += flytime;
                p1 = path_optimizer.path[i];
                distance = path_optimizer.cal_distance(p1, init_location);

                if (current.arrive < current.depart) {
                    if (distance > 0.01) {
                        worktime += current.depart - current.arrive;
                    } else {
                        worktime += T_charge;
                    }
                }               
            }
            reward -= worktime * alpha;
            ouT_come.profits = reward;
        }
    }
    return ouT_come;
}

// 从文件读取数据
std::tuple<double, double, double, int, int, std::vector<Point>, std::vector<int>>
read_from_file(const std::string& filename) {
    std::ifstream file(filename);
    if (!file.is_open()) {
        std::cerr << "Error opening file: " << filename << std::endl;
        exit(1);
    }
    
    double width, length, energy_max;
    int M, N;
    
    // 读取第一行数据
    file >> width >> length >> energy_max >> M >> N;
    file.close();
    
    // 重新打开文件读取传感器数据
    file.open(filename);
    std::string line;
    std::getline(file, line); // 跳过第一行
    
    std::vector<Point> sensor_pos;
    std::vector<int> Ri;
    
    while (std::getline(file, line)) {
        std::istringstream iss(line);
        double x, y, prof;
        iss >> x >> y >> prof;
        
        sensor_pos.push_back(Point{x, y});
        Ri.push_back(prof);
    }
    
    file.close();
    return {width, length, energy_max, M, N, sensor_pos, Ri};
} 

int main() {
    std::string mode = "GEN_SCH_SCORE";
    Result outcome;
    
    if (mode.find("GEN_SCH_SCORE") != std::string::npos) {
        std::string score_path = "./final_score.txt";
        std::ofstream f(score_path);
        
        int n_tests = 5;
        double total_score = 0;
        std::vector<double> score_list(n_tests, 0.0);
        
        for (int i = 1; i <= n_tests; i++) {
            std::cerr << "\ntest case #" << i << ": ";
            
            InteractiveSystem inter_sys;
            std::string file_name = "./data/" + std::to_string(i) + ".in";
            inter_sys.init(file_name);
            
            outcome = inter_sys.runOnce();
            
            std::cerr << outcome.is_success << " " << std::fixed << std::setprecision(2) << outcome.profits << std::endl;
            
            if (outcome.is_success) {
                std::string baseline_file_name = "./data/baseline_" + std::to_string(i) + ".out";
                std::ifstream baseline_file(baseline_file_name);
                
                if (baseline_file.is_open()) {
                    std::string line;
                    std::getline(baseline_file, line);
                    double baseline = std::stod(line);
                    double score = std::min(MAX_SCORE, 1.0 * outcome.profits / baseline * SCORE_OF_BASLINE);
                    total_score += score;
                    std::cerr << std::fixed << std::setprecision(2) << score << std::endl;
                    score_list[i-1] = score;
                }
                baseline_file.close();
            } else {
                score_list[i-1] = 0.0;
            }

        }
        
        std::cerr << "Final Score: " << std::fixed << std::setprecision(2) << (total_score / n_tests) << std::endl;
        f << "Final Score: " << std::fixed << std::setprecision(2) << (total_score / n_tests) << std::endl;
        
        for (int i = 0; i < n_tests; i++) {
            f << "Score of Test Case #" << (i + 1) << ": " << std::fixed << std::setprecision(2) << score_list[i] << std::endl;
        }
        
        f.close();
    }
    
    return 0;
} 