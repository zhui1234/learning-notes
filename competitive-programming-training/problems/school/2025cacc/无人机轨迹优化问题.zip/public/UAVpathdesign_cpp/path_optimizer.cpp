#include "path_optimizer.h"
#include <set>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <iostream>

const double MAX_LEN = 10.0;

// 构造函数
PathOptimizer::PathOptimizer() {
    width = 0;
    length = 0;
    M = 0;
    N = 0;
    init_location = {0.0, 0.0};
    E_max = 0.0;
    V_max = 30;  // 最大飞行速度
    D_max = 300;  // 无人机覆盖半径/m
    alpha = 0.1;  // 折扣系数
    T_com = 1;  // 一次数据传输时间
    T_charge = 120;  // 一次充电时间
}

// 初始化函数
void PathOptimizer::init(double length, double width, double E_max, int M, int N,
                         const std::vector<Point>& sensor_pos, const std::vector<int>& Ri) {
    this->length = length;
    this->width = width;
    this->E_max = E_max;
    this->M = M;
    this->N = N;
    this->sensor_pos = sensor_pos;
    this->Ri = Ri;

    visited.resize(M, 0);
    sampletime.resize(M, 0.0);
    offloadtime.resize(M, 0.0);
}

// TODO: 在这个函数中完成路径规划功能，注意返回数据结构格式
// 返回profits, 其他数据收集点信息（路径长度，飞行路径，时间标签，所收集的节点序号）和 节点信息（采样时间，卸载时间）放在PathOptimizer类成员中
double PathOptimizer::run() {
    double profits = -1.0;

    return profits;
}

// 计算两点之间的距离
double PathOptimizer::cal_distance(const Point& point1, const Point& point2) {
    double x1 = point1.x;
    double y1 = point1.y;
    double x2 = point2.x;
    double y2 = point2.y;
    
    return std::sqrt(std::pow(x1 - x2, 2) + std::pow(y1 - y2, 2));
}

// 计算UAV功率
double PathOptimizer::cal_uav_power(double v) {
    const double P0 = 79.8563;
    const double P1 = 88.6279;
    const double a = 0.00021;
    const double b = 0.00924;
    const double c = 0.00073;
    const double d = 0.02704;
    
    double power = P0 * (1 + a * std::pow(v, 2)) + b * std::pow(v, 3) + 
                   P1 * std::sqrt(std::sqrt(1 + c * std::pow(v, 4)) - d * std::pow(v, 2));
    
    return power;
}

