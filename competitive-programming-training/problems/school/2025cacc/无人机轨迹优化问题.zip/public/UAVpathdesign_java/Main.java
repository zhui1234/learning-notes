import java.io.*;
import java.util.*;

public class Main {
    private static final double MAX_SCORE = 300.0;
    private static final double SCORE_OF_BASELINE = 300.0 * 0.7;

    public static class InteractiveSystem {
        private int width;       // 环境宽度 单位m
        private int length;      // 环境长度
        private int M;           // 节点数量 M
        private int N;           // UAV一次访问节点数 N
        private double E_max;
        private int V_max = 30;  // 最大飞行速度
        private int D_max = 300; // 无人机覆盖半径/m
        private double alpha = 0.1; // 折扣系数
        private int T_com = 1;   // 一次数据传输时间
        private int T_charge = 120; // 一次充电时间
        private double[] init_location = {0.0, 0.0};

        private List<double[]> sensor_pos = new ArrayList<>();
        private List<Integer> Ri = new ArrayList<>(); // profits of sensor nodes
        private double profits = -1.0;
        private Object[] path;
        private double[][] sensor;
        private PathOptimizer path_optimizer = new PathOptimizer();

        public InteractiveSystem() {
        }

        public void init(String file_name) {
            this.alpha = 0.1;
            this.V_max = 30;  // 最大飞行速度
            this.D_max = 300; // 无人机覆盖半径/m
            this.T_com = 1;   // 一次数据传输时间
            this.T_charge = 120; // 一次充电时间
            this.init_location = new double[]{0.0, 0.0};
            Object[] result = readFromFile(file_name);
            this.length = (int) result[0];
            this.width = (int) result[1];
            this.E_max = (double) result[2];
            this.M = (int) result[3];
            this.N = (int) result[4];
            this.sensor_pos = (List<double[]>) result[5];
            this.Ri = (List<Integer>) result[6];
            this.path_optimizer.init(this.width, this.length, this.E_max, this.M, this.N, this.sensor_pos, this.Ri);
        }

        public Map<String, Object> runOnce() {
            Object[] result = this.path_optimizer.run();
            this.profits = (double) result[0];
            this.path = (Object[]) result[1];
            this.sensor = (double[][]) result[2];

            boolean is_success = true;
            int[] visited = new int[this.M];
            Arrays.fill(visited, 1);

            int num_pos = (int) this.path[0];  // 数据收集点数（不包括驻点）
            List<double[]> uav_path = (List<double[]>) this.path[1];     // 无人机轨迹（包括离开和回到驻点）
            List<double[]> time_seq = (List<double[]>) this.path[2];     // 到达和离开数据收集点时间, 首次从驻点离开时间为（0，0）
            List<List<Integer>> visit_sn = (List<List<Integer>>) this.path[3];     // 在每个数据收集点访问的节点序号

            // 检查是否满足能量要求
            double remaining_e_uav = this.E_max;
            double reward = 0.0;
            double worktime = 0.0;

            // 检查结果
            if (this.profits < 0.0 || uav_path.size() != num_pos || time_seq.size() != num_pos || visit_sn.size() != num_pos) {
                is_success = false;
            } else {
                for (int i = 1; i < num_pos - 1; i++) {
                    double pos_x = uav_path.get(i)[0];
                    double pos_y = uav_path.get(i)[1];
                    if (pos_x > this.length || pos_x < 0) {
                        is_success = false;
                    }
                    if (pos_y > this.width || pos_y < 0) {
                        is_success = false;
                    }
                    double time_arrive = time_seq.get(i)[0];
                    double time_depart = time_seq.get(i)[1];
                    if (time_depart < time_arrive) {
                        is_success = false;
                    } else {
                        double time_arrive2 = time_seq.get(i - 1)[0];
                        double time_depart2 = time_seq.get(i - 1)[1];
                        if (time_depart2 >= time_arrive) {
                            is_success = false;
                        }
                    }
                    List<Integer> sn_ind = visit_sn.get(i);
                    for (int j = 0; j < sn_ind.size(); j++) {
                        visited[sn_ind.get(j)] = 1;
                    }
                }

                int sum = 0;
                for (int v : visited) {
                    sum += v;
                }

                if (sum != this.M) {
                    is_success = false;
                } else {
                    for (int i = 1; i < num_pos; i++) {  // 循环所有点
                        double distance = this.path_optimizer.calDistance(uav_path.get(i - 1), uav_path.get(i));
                        double flytime = time_seq.get(i)[0] - time_seq.get(i - 1)[1];
                        if (flytime > 0) {
                            double velocity = distance / flytime;
                            if (velocity > this.V_max && Math.abs(velocity - this.V_max) > 0.01) {
                                is_success = false;
                            } else {
                                remaining_e_uav -= this.path_optimizer.calUavPower(velocity) * flytime;
                            }
                        } else {
                            is_success = false;
                        }

                        double[] init_loc = this.init_location;
                        double dist_intial = this.path_optimizer.calDistance(uav_path.get(i), init_loc);
                        if (dist_intial > 0.1 && visit_sn.get(i).size() > 0) {
                            int nn = (int) Math.ceil((double) visit_sn.get(i).size() / this.N);  // nn次传输
                            remaining_e_uav -= this.path_optimizer.calUavPower(0) * (nn * this.T_com);
                        }

                        if (i < num_pos - 1 && dist_intial <= 0.1) {
                            remaining_e_uav = this.E_max;
                        }

                        if (remaining_e_uav < 0) {
                            is_success = false;
                            break;
                        }
                    }
                }

                if (is_success) {  // check profits
                    for (int i = 0; i < this.M; i++) {
                        if (Math.abs(this.sensor[1][i] - this.sensor[0][i]) < 1e-6) {
                            reward += this.Ri.get(i);
                        } else {
                            reward += this.Ri.get(i) / (this.sensor[1][i] - this.sensor[0][i]);
                        }
                    }

                    for (int i = 1; i < num_pos; i++) {
                        worktime += time_seq.get(i)[0] - time_seq.get(i - 1)[1];
                        if (time_seq.get(i)[0] < time_seq.get(i)[1]) {
                            double[] init_loc = this.init_location;
                            boolean isInitLocation = Math.abs(uav_path.get(i)[0] - init_loc[0]) < 1e-6 && 
                                                   Math.abs(uav_path.get(i)[1] - init_loc[1]) < 1e-6;
                            if (!isInitLocation) {
                                worktime += time_seq.get(i)[1] - time_seq.get(i)[0];
                            } else {
                                worktime += this.T_charge;
                            }
                        }
                    }

                    reward -= worktime * this.alpha;
                }
            }

            Map<String, Object> result_map = new HashMap<>();
            result_map.put("is_success", is_success);
            result_map.put("reward", reward);
            return result_map;
        }
    }

    public static Object[] readFromFile(String filename) {
        int width = 0;
        int length = 0;
        double energy_max = 0.0;
        int M = 0;
        int N = 0;
        List<double[]> sensor_pos = new ArrayList<>();
        List<Integer> Ri = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line = br.readLine();
            String[] parts = line.split("\\s+");
            width = Integer.parseInt(parts[0]);
            length = Integer.parseInt(parts[1]);
            energy_max = Double.parseDouble(parts[2]);
            M = Integer.parseInt(parts[3]);
            N = Integer.parseInt(parts[4]);

            BufferedReader br2 = new BufferedReader(new FileReader(filename));
            br2.readLine(); // 跳过第一行
            
            String line2;
            while ((line2 = br2.readLine()) != null) {
                String[] parts2 = line2.split("\\s+");
                double x = Double.parseDouble(parts2[0]);
                double y = Double.parseDouble(parts2[1]);
                int prof = Integer.parseInt(parts2[2]);
                
                double[] pos = {x, y};
                sensor_pos.add(pos);
                Ri.add(prof);
            }
            br2.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return new Object[]{width, length, energy_max, M, N, sensor_pos, Ri};
    }

    public static void main(String[] args) {
        String mode = "GEN_SCH_SCORE";

        if (mode.contains("GEN_SCH_SCORE")) {
            String score_path = "./final_score.txt";
            try (PrintWriter writer = new PrintWriter(new FileWriter(score_path))) {
                int n_tests = 5;
                double total_score = 0;
                double[] score_list = new double[n_tests];

                for (int i = 1; i <= n_tests; i++) {
                    System.err.print("\ntest case #" + i + ": ");
                    InteractiveSystem inter_sys = new InteractiveSystem();
                    String file_name = "./data/" + i + ".in";
                    inter_sys.init(file_name);
                    Map<String, Object> result = inter_sys.runOnce();
                    boolean is_success = (boolean) result.get("is_success");
                    double profits = (double) result.get("reward");
                    
                    System.err.printf("%b %.2f \n", is_success, profits);
                    
                    if (is_success) {
                        String baseline_file_name = "./data/baseline_" + i + ".out";
                        try (BufferedReader br = new BufferedReader(new FileReader(baseline_file_name))) {
                            String line = br.readLine().trim();
                            double baseline = Double.parseDouble(line);
                            double score = Math.min(MAX_SCORE, 1.0 * profits / baseline * SCORE_OF_BASELINE);
                            total_score += score;
                            System.err.printf("%.2f%n", score);
                            score_list[i - 1] = score;
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                    } else {
                        score_list[i - 1] = 0.0;
                    }
                }
                
                System.err.printf("Final Score: %.2f%n", (total_score / n_tests));
                writer.printf("Final Score: %.2f%n", (total_score / n_tests));
                
                for (int i = 0; i < n_tests; i++) {
                    writer.printf("Score of Test Case #%d: %.2f%n", i + 1, score_list[i]);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }
} 