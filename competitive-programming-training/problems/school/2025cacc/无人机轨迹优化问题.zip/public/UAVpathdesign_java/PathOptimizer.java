import java.util.*;

public class PathOptimizer {
    private int width;  // 环境宽度 单位m
    private int length;  // 环境长度
    private int M;  // 节点数量 M
    private int N;  // UAV一次访问节点数 N
    private double[] init_location = {0.0, 0.0};
    private double E_max;
    private int V_max = 30;  // 最大飞行速度
    private int D_max = 300;  // 无人机覆盖半径/m
    private double alpha = 0.1;  // 折扣系数discount
    private int T_com = 1;  // 一次数据传输时间
    private int T_charge = 120;  // 一次充电时间

    private List<double[]> sensor_pos = new ArrayList<>();
    private List<Integer> Ri = new ArrayList<>();  // profits of sensor nodes
    private int[] visited;  // visiting state
    private List<Double> remaining_e_uav = new ArrayList<>();  // UAV的剩余电量
    private List<double[]> path = new ArrayList<>();
    private List<double[]> timelabel = new ArrayList<>();
    private double[] sampletime;
    private double[] offloadtime;
    private List<List<Integer>> sensor_visited = new ArrayList<>();

    public PathOptimizer() {
    }

    public void init(int length, int width, double E_max, int M, int N,
                   List<double[]> sensor_pos, List<Integer> Ri) {
        this.length = length;  // 环境长度
        this.width = width;  // 环境宽度 单位m
        this.E_max = E_max;
        this.M = M;  // 节点数量 M
        this.N = N;  // UAV一次访问节点数 N
        this.sensor_pos = sensor_pos;
        this.Ri = Ri;

        this.visited = new int[this.M];
        this.sampletime = new double[this.M];
        this.offloadtime = new double[this.M];
    }

    // TODO: 在这个函数中完成路径规划功能，注意返回数据结构格式
    // 返回profits, 数据收集点信息（路径长度，飞行路径，时间标签，所收集的节点序号）， 节点信息（采样时间，卸载时间）对
  
    public Object[] run() {
        double profits = -1.0;
    
        return new Object[]{profits, new Object[]{this.path.size(), this.path, this.timelabel, this.sensor_visited}, new double[][]{this.sampletime, this.offloadtime}};
    }

 

    public double calDistance(double[] point1, double[] point2) {
        return Math.sqrt(Math.pow(point1[0] - point2[0], 2) + Math.pow(point1[1] - point2[1], 2));
    }

    public double calUavPower(double v) {
        double P0 = 79.8563;
        double P1 = 88.6279;
        double a = 0.00021;
        double b = 0.00924;
        double c = 0.00073;
        double d = 0.02704;

        double power = P0 * (1 + a * Math.pow(v, 2)) + b * Math.pow(v, 3) + 
                P1 * Math.sqrt(Math.sqrt(1 + c * Math.pow(v, 4)) - d * Math.pow(v, 2));

        return power;
    }
} 